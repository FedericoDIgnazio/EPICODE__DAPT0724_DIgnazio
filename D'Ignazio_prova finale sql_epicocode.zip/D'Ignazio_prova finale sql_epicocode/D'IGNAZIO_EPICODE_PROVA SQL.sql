CREATE DATABASE epicode_prova_sql3;

USE epicode_prova_sql3;

-- Creazione della tabella Region
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50)
);

-- Creazione della tabella State
CREATE TABLE State (
    StateID INT PRIMARY KEY,
    StateName VARCHAR(50),
    RegionID INT,
    CONSTRAINT FK_Region_State FOREIGN KEY (RegionID) REFERENCES Region (RegionID)
);

-- Creazione della tabella Category
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    Description VARCHAR(50)
);

-- Creazione della tabella Product
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    CategoryID INT,
    CONSTRAINT FK_Category_Product FOREIGN KEY (CategoryID) REFERENCES Category (CategoryID)
);

-- Creazione della tabella Sales
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    StateID INT,
    SaleDate DATE,
    Quantity INT,
    ListPrice INT,
    Amount INT,
    CONSTRAINT FK_Product_Sales FOREIGN KEY (ProductID) REFERENCES Product (ProductID),
    CONSTRAINT FK_State_Sales FOREIGN KEY (StateID) REFERENCES State (StateID)
);

-- Popolamento della tabella Region
INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'WestEurope'),
(2, 'SouthEurope');

-- Popolamento della tabella State
INSERT INTO State (StateID, StateName, RegionID) VALUES
(1, 'France', 1),
(2, 'Germany', 1),
(3, 'Italy', 2),
(4, 'Greece', 2),
(5, 'Spain', 2);

-- Popolamento della tabella Category
INSERT INTO Category (CategoryID, Description) VALUES
(1, 'Plush Toys'),
(2, 'Action Figures'),
(3, 'Educational Toys'),
(4, 'Dolls & Furniture');

-- Popolamento della tabella Product
INSERT INTO Product (ProductID, ProductName, CategoryID) VALUES
(1, 'Teddy Bear', 1),
(2, 'Toy Car Set', 2),
(3, 'Building Blocks', 3),
(4, 'Dollhouse', 4),
(5, 'Board Game', 4);

-- Popolamento della tabella Sales (ordinato per anno)
INSERT INTO Sales (SaleID, ProductID, StateID, SaleDate, Quantity, ListPrice, Amount) VALUES

(1, 1, 1, '2022-03-15', 10, 30, (30 * 10)),
(2, 2, 1, '2022-06-20', 5, 50, (50 * 5)),
(3, 3, 2, '2022-09-10', 20, 40, (40 * 20)),
(4, 4, 2, '2022-11-05', 15, 100, (100 * 15)),
(16, 1, 1, '2022-02-05', 12, 30, (30 * 12)),
(17, 2, 1, '2022-07-13', 18, 50, (50 * 18)),
(18, 3, 2, '2022-09-25', 22, 40, (40 * 22)),
(19, 4, 2, '2022-11-10', 13, 100, (100 * 13)),
(6, 1, 1, '2023-01-12', 25, 30, (30 * 25)),
(7, 2, 3, '2023-02-15', 10, 50, (50 * 10)),
(8, 3, 2, '2023-04-10', 30, 40, (40 * 30)),
(9, 4, 2, '2023-07-22', 12, 100, (100 * 12)),
(21, 1, 4, '2023-02-05', 10, 30, (30 * 10)),
(22, 2, 1, '2023-03-16', 14, 50, (50 * 14)),
(23, 3, 2, '2023-04-05', 17, 40, (40 * 17)),
(24, 4, 2, '2023-08-01', 11, 100, (100 * 11)),
(26, 1, 1, '2023-12-20', 20, 30, (30 * 20)),
(11, 1, 1, '2024-01-09', 18, 30, (30 * 18)),
(12, 2, 1, '2024-05-11', 14, 50, (50 * 14)),
(13, 3, 2, '2024-08-16', 22, 40, (40 * 22)),
(14, 4, 3, '2024-10-05', 10, 100, (100 * 10)),
(27, 2, 3, '2024-01-15', 9, 50, (50 * 9)),
(28, 3, 3, '2024-03-02', 15, 40, (40 * 15)),
(29, 4, 3, '2024-06-12', 8, 100, (100 * 8));


-- task 1 Verifica dell'univocità dei valori nelle tabelle

SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT StateID, COUNT(*)
FROM State
GROUP BY StateID
HAVING COUNT(*) > 1;

SELECT CategoryID, COUNT(*)
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SELECT ProductID, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT SaleID, COUNT(*)
FROM Sales
GROUP BY SaleID
HAVING COUNT(*) > 1;

-- task 2)
SELECT 
    s.SaleID AS CodiceDocumento, 
    s.SaleDate AS Data,
    p.ProductName AS NomeProdotto,
    c.Description AS CategoriaProdotto,
    st.StateName AS NomeStato,
    r.RegionName AS NomeRegione,
    -- Calcolo booleano per determinare se sono passati più di 180 giorni
    IF(DATEDIFF(CURDATE(), s.SaleDate) > 180, TRUE, FALSE) AS PiùDi180Giorni
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN 
    Category c ON p.CategoryID = c.CategoryID
JOIN 
    State st ON s.StateID = st.StateID
JOIN 
    Region r ON st.RegionID = r.RegionID;

-- task 3: Query per ottenere l'elenco dei prodotti con totale venduto maggiore della media nel 2024

SELECT 
    p.ProductID AS CodiceProdotto,
    SUM(s.Quantity) AS TotaleVenduto
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
WHERE 
    YEAR(s.SaleDate) = 2024  -- Consideriamo solo l'anno 2024
GROUP BY 
    p.ProductID
HAVING 
    SUM(s.Quantity) > (
        SELECT AVG(TotaleVendite)
        FROM (
            SELECT SUM(s.Quantity) AS TotaleVendite
            FROM Sales s
            WHERE YEAR(s.SaleDate) = 2024  -- Solo le vendite del 2024
            GROUP BY s.ProductID
        ) AS vendite_annuali
    );
    
-- task 4: query per ottenere il fatturato totale per ogni prodotto per anno

    select p.ProductID AS CodiceProdotto,
    YEAR(s.SaleDate) AS Anno,
    SUM(s.Quantity * s.ListPrice) AS FatturatoTotale
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
GROUP BY 
    p.ProductID, YEAR(s.SaleDate)
ORDER BY 
    p.ProductID, YEAR(s.SaleDate);

-- task 5: Query per ottenere il fatturato totale per stato per anno
SELECT 
    st.StateName AS NomeStato,
    YEAR(s.SaleDate) AS Anno,
    SUM(s.Quantity * s.ListPrice) AS FatturatoTotale
FROM 
    Sales s
JOIN 
    State st ON s.StateID = st.StateID
GROUP BY 
    st.StateName, YEAR(s.SaleDate)
ORDER BY 
    Anno, FatturatoTotale DESC;
    

-- task 7: Query per ottenere la categoria con la maggiore quantità venduta
SELECT 
    c.Description AS Categoria,
    SUM(s.Quantity) AS TotaleVenduto
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN 
    Category c ON p.CategoryID = c.CategoryID
GROUP BY 
    c.Description
ORDER BY 
    TotaleVenduto DESC
LIMIT 1;

-- task 7:  Query per ottenere i prodotti invenduti
-- 1)
SELECT 
    p.ProductID AS CodiceProdotto,
    p.ProductName AS NomeProdotto
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
WHERE 
    s.SaleID IS NULL;  -- Filtra per i prodotti che non hanno vendite
-- 2)

SELECT 
    p.ProductID AS CodiceProdotto,
    p.ProductName AS NomeProdotto
FROM 
    Product p
WHERE 
    NOT EXISTS (
        SELECT 1
        FROM Sales s
        WHERE s.ProductID = p.ProductID
    );



-- task 9 Creazione della vista per le informazioni geografiche
CREATE VIEW vw_GeographicInfo AS
SELECT 
    r.RegionID AS CodiceRegione,
    r.RegionName AS NomeRegione,
    s.StateID AS CodiceStato,
    s.StateName AS NomeStato
FROM 
    Region r
JOIN 
    State s ON r.RegionID = s.RegionID;
SELECT * FROM vw_GeographicInfo;


-- task 8Creazione della vista per i prodotti e le categorie
CREATE VIEW vw_ProductCategory AS
SELECT 
    p.ProductID AS CodiceProdotto,
    p.ProductName AS NomeProdotto,
    c.Description AS NomeCategoria
FROM 
    Product p
JOIN 
    Category c ON p.CategoryID = c.CategoryID;
SELECT * FROM vw_ProductCategory;